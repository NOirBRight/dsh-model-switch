# node-addon-require-builtin-win32-arm64-msvc

Optional prebuilt native addon package for `win32-arm64-msvc`.

The main `node-addon-require-builtin` package selects one binary from
this package at runtime using `prebuilds.json`.
