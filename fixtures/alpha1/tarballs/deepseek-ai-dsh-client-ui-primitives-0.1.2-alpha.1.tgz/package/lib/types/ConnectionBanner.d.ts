/**
 * Render the reconnecting banner.
 * @param props.reconnecting - true while the connection is in backoff/retry.
 * @param props.label - banner text; the owner passes localized copy (this
 * package is cordis-free, so copy arrives via props).
 * @returns the banner, or null when connected.
 */
export declare function ConnectionBanner({ reconnecting, label }: {
    reconnecting: boolean;
    label: string;
}): import("react").JSX.Element | null;
//# sourceMappingURL=ConnectionBanner.d.ts.map